// Referencias a los elementos del DOM
const bannerTrigger = document.getElementById('banner-trigger');
const backdrop = document.getElementById('vip-modal-backdrop');
const closeBtn = document.getElementById('close-btn');
const confirmBtn = document.getElementById('confirm-btn');
const profileCard = document.getElementById('demo-profile-card');
const songTitle = document.getElementById('preview-song-title');
const chips = document.querySelectorAll('.skin-chip');

// Abrir modal al hacer clic en el banner
bannerTrigger.addEventListener('click', () => {
    backdrop.classList.add('active');
});

// Cerrar con la cruz
closeBtn.addEventListener('click', () => {
    backdrop.classList.remove('active');
});

// Cerrar si hace clic fuera del modal (en el fondo oscuro)
backdrop.addEventListener('click', (event) => {
    if (event.target === backdrop) {
        backdrop.classList.remove('active');
    }
});

// Cambiar de tema en la previsualización
chips.forEach((chip) => {
    chip.addEventListener('click', () => {
        chips.forEach(c => c.classList.remove('active'));
        chip.classList.add('active');

        const theme = chip.getAttribute('data-theme');
        profileCard.className = 'profile-mini-card';

        if (theme === 'cyber') {
            profileCard.classList.add('theme-cyber');
            songTitle.innerText = "Escuchando: Daft Punk - Voyager";
        } else if (theme === 'y2k') {
            profileCard.classList.add('theme-y2k');
            songTitle.innerText = "Escuchando: Gorillaz - 19-2000";
        } else if (theme === 'gold') {
            profileCard.classList.add('theme-gold');
            songTitle.innerText = "Escuchando: Kavinsky - Nightcall";
        }
    });
});

// Confirmación de la prueba
confirmBtn.addEventListener('click', () => {
    alert("¡Genial! Activaste tus 3 meses gratis del Pase Estelar Órbita. 🚀👑");
    backdrop.classList.remove('active');
});